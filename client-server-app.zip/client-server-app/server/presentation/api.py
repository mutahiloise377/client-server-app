"""PRESENTATION (API) LAYER
The only layer that speaks HTTP. It reads the request, hands the work to the
business layer, and turns the result (or error) into a JSON response with the
right status code. It contains no business rules and no SQL.
"""
import json
import logging
import re
from http.server import BaseHTTPRequestHandler

from business.service import ConflictError, NotFoundError, ValidationError

log = logging.getLogger("server")

ID_ROUTE = re.compile(r"^/api/students/(\d+)$")


def make_handler(service):
    class Handler(BaseHTTPRequestHandler):
        server_version = "SimpleStudentServer/1.0"

        # --- helpers -----------------------------------------------------
        def _send(self, status, payload=None):
            body = json.dumps(payload if payload is not None else {}).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            log.info("[PRESENTATION] <- response %s", status)

        def _read_json(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                raise ValidationError("Request body is not valid JSON")

        def _handle(self, action):
            log.info("[PRESENTATION] -> %s %s", self.command, self.path)
            try:
                status, payload = action()
                self._send(status, payload)
            except ValidationError as e:
                self._send(400, {"error": str(e)})
            except NotFoundError as e:
                self._send(404, {"error": str(e)})
            except ConflictError as e:
                self._send(409, {"error": str(e)})
            except Exception as e:  # unexpected problem
                log.exception("unexpected error")
                self._send(500, {"error": "Internal server error"})

        # --- HTTP verbs -> business operations -----------------------------
        def do_GET(self):
            def action():
                if self.path == "/api/health":
                    return 200, {"status": "ok"}
                if self.path == "/api/students":
                    return 200, service.list_students()
                m = ID_ROUTE.match(self.path)
                if m:
                    return 200, service.get_student(int(m.group(1)))
                return 404, {"error": "Route not found"}
            self._handle(action)

        def do_POST(self):
            def action():
                if self.path == "/api/students":
                    return 201, service.create_student(self._read_json())
                return 404, {"error": "Route not found"}
            self._handle(action)

        def do_PUT(self):
            def action():
                m = ID_ROUTE.match(self.path)
                if m:
                    return 200, service.update_student(int(m.group(1)), self._read_json())
                return 404, {"error": "Route not found"}
            self._handle(action)

        def do_DELETE(self):
            def action():
                m = ID_ROUTE.match(self.path)
                if m:
                    service.delete_student(int(m.group(1)))
                    return 200, {"message": "Student deleted"}
                return 404, {"error": "Route not found"}
            self._handle(action)

        def log_message(self, format, *args):  # silence default noisy logging
            pass

    return Handler
