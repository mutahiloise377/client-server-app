"""Entry point: wires the three layers together and starts the server.

    Data layer  ->  Business layer  ->  Presentation layer  ->  (HTTP) -> Client
"""
import logging
import sys
from http.server import ThreadingHTTPServer

from data.repository import StudentRepository
from business.service import StudentService
from presentation.api import make_handler

HOST, PORT = "127.0.0.1", 8080

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(message)s",
    datefmt="%H:%M:%S",
    stream=sys.stdout,
)


def main():
    repository = StudentRepository()                 # bottom layer
    service = StudentService(repository)             # middle layer (gets the data layer)
    handler = make_handler(service)                  # top layer (gets the business layer)
    server = ThreadingHTTPServer((HOST, PORT), handler)
    logging.info("Server listening on http://%s:%s", HOST, PORT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logging.info("Server stopped")
        server.server_close()


if __name__ == "__main__":
    main()
