"""DATA LAYER
Only this layer talks to the database (SQLite). It knows nothing about HTTP
or business rules - it just stores and fetches rows.
"""
import sqlite3
import logging

log = logging.getLogger("server")


class StudentRepository:
    def __init__(self, db_path=":memory:"):
        # check_same_thread=False because the HTTP server may use several threads
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS students (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   reg_no TEXT UNIQUE NOT NULL,
                   name TEXT NOT NULL,
                   program TEXT NOT NULL
               )"""
        )
        self.conn.commit()

    def get_all(self):
        log.info("[DATA        ] SELECT * FROM students")
        rows = self.conn.execute("SELECT * FROM students ORDER BY id").fetchall()
        return [dict(r) for r in rows]

    def get_by_id(self, student_id):
        log.info("[DATA        ] SELECT ... WHERE id=%s", student_id)
        row = self.conn.execute(
            "SELECT * FROM students WHERE id = ?", (student_id,)
        ).fetchone()
        return dict(row) if row else None

    def get_by_reg_no(self, reg_no):
        row = self.conn.execute(
            "SELECT * FROM students WHERE reg_no = ?", (reg_no,)
        ).fetchone()
        return dict(row) if row else None

    def insert(self, reg_no, name, program):
        log.info("[DATA        ] INSERT INTO students (%s)", reg_no)
        cur = self.conn.execute(
            "INSERT INTO students (reg_no, name, program) VALUES (?, ?, ?)",
            (reg_no, name, program),
        )
        self.conn.commit()
        return cur.lastrowid

    def update(self, student_id, name, program):
        log.info("[DATA        ] UPDATE students WHERE id=%s", student_id)
        cur = self.conn.execute(
            "UPDATE students SET name = ?, program = ? WHERE id = ?",
            (name, program, student_id),
        )
        self.conn.commit()
        return cur.rowcount > 0

    def delete(self, student_id):
        log.info("[DATA        ] DELETE FROM students WHERE id=%s", student_id)
        cur = self.conn.execute("DELETE FROM students WHERE id = ?", (student_id,))
        self.conn.commit()
        return cur.rowcount > 0
