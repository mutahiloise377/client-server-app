"""BUSINESS (LOGIC) LAYER
Holds the rules of the application: what counts as a valid student, no
duplicate registration numbers, what happens when a student is not found.
It does not know about HTTP and does not write SQL.
"""
import re
import logging

log = logging.getLogger("server")

REG_NO_PATTERN = re.compile(r"^[A-Z]{2,4}/\d{3,5}/\d{2}$")  # e.g. DS/1234/23


class ValidationError(Exception):
    """Data sent by the client breaks a rule (HTTP 400)."""


class NotFoundError(Exception):
    """The requested student does not exist (HTTP 404)."""


class ConflictError(Exception):
    """The request clashes with existing data (HTTP 409)."""


class StudentService:
    def __init__(self, repository):
        self.repo = repository

    def list_students(self):
        log.info("[BUSINESS    ] list_students()")
        return self.repo.get_all()

    def get_student(self, student_id):
        log.info("[BUSINESS    ] get_student(%s)", student_id)
        student = self.repo.get_by_id(student_id)
        if student is None:
            raise NotFoundError(f"Student {student_id} not found")
        return student

    def create_student(self, data):
        log.info("[BUSINESS    ] create_student() - validating input")
        reg_no = str(data.get("reg_no", "")).strip().upper()
        name = str(data.get("name", "")).strip()
        program = str(data.get("program", "")).strip()

        if not reg_no or not name or not program:
            raise ValidationError("reg_no, name and program are all required")
        if not REG_NO_PATTERN.match(reg_no):
            raise ValidationError("reg_no must look like DS/1234/23")
        if self.repo.get_by_reg_no(reg_no):
            raise ConflictError(f"Registration number {reg_no} already exists")

        new_id = self.repo.insert(reg_no, name, program)
        return self.repo.get_by_id(new_id)

    def update_student(self, student_id, data):
        log.info("[BUSINESS    ] update_student(%s)", student_id)
        self.get_student(student_id)  # raises NotFoundError if missing
        name = str(data.get("name", "")).strip()
        program = str(data.get("program", "")).strip()
        if not name or not program:
            raise ValidationError("name and program are required")
        self.repo.update(student_id, name, program)
        return self.repo.get_by_id(student_id)

    def delete_student(self, student_id):
        log.info("[BUSINESS    ] delete_student(%s)", student_id)
        self.get_student(student_id)  # raises NotFoundError if missing
        self.repo.delete(student_id)
