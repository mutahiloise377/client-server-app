# Layered Client-Server Application (Student Registry)

A simple client-server application that runs on localhost. The server has three layers
(presentation, business, data) and the client talks to it over HTTP using JSON.

> **AI assistance disclosure:** This project was built with help from Claude (an AI assistant
> by Anthropic). Replace or extend this note with your own account of what you did and learned,
> as your unit's rules require.

## Structure
- `server/app.py` starts the server on http://127.0.0.1:8080 and connects the layers
- `server/presentation/api.py` Layer 1: HTTP routes, JSON, status codes
- `server/business/service.py` Layer 2: rules and validation
- `server/data/repository.py` Layer 3: SQLite database access
- `client/client.py` the client that calls the server
- `docs/` the written report (.docx) and a web page version (`index.html`)
- `sample-output/` captured client output and server log from a real run

## Run it (Python 3 only, nothing to install)
Terminal 1:
```
cd server
python3 app.py
```
Terminal 2:
```
cd client
python3 client.py
```
