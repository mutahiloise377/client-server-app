"""CLIENT
A small command-line client that talks to the server over HTTP (JSON).
Running it executes a demo: health check, create, read, update, delete,
and two deliberate error cases (bad input and unknown id).
"""
import json
import urllib.request
import urllib.error

BASE = "http://127.0.0.1:8080"
results = []  # collected so the report can show them


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            status, text = resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:   # 4xx / 5xx still carry a JSON body
        status, text = e.code, e.read().decode()
    payload = json.loads(text)
    print(f"\n>>> {method} {path}" + (f"   body={json.dumps(body)}" if body else ""))
    print(f"<<< {status}  {json.dumps(payload)}")
    results.append({"method": method, "path": path, "request": body,
                    "status": status, "response": payload})
    return status, payload


if __name__ == "__main__":
    print("=== CLIENT DEMO ===")
    call("GET", "/api/health")
    call("POST", "/api/students", {"reg_no": "DS/1001/23", "name": "Loise Mutahi", "program": "BSc Data Science"})
    call("POST", "/api/students", {"reg_no": "DS/1002/23", "name": "Amani Otieno", "program": "BSc Data Science"})
    call("GET", "/api/students")
    call("GET", "/api/students/1")
    call("PUT", "/api/students/2", {"name": "Amani Otieno", "program": "BSc Computer Science"})
    call("DELETE", "/api/students/2")
    print("\n--- error cases ---")
    call("POST", "/api/students", {"reg_no": "bad-number", "name": "X", "program": "Y"})
    call("POST", "/api/students", {"reg_no": "DS/1001/23", "name": "Duplicate", "program": "Y"})
    call("GET", "/api/students/99")
    call("GET", "/api/students")
    with open("client_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nAll requests completed.")
